﻿using Microsoft.Practices.ServiceLocation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Zipkin.Tracer.Examples.AspNet
{
    public class AutowireApplication : HttpApplication
    {
        public override void Init()
        {
            base.Init();
            InitializeModules();
        }

        protected virtual void InitializeModules()
        {
            var modules = ServiceLocator.Current.GetAllInstances<IHttpModule>();
            if (modules == null) return;
            foreach (IHttpModule module in modules)
            {
                module.Init(this);
            }
        }
    }
}